2024-08-26 과제 제출 (연락처 앱)

1. 이름과 전화번호 중 빈칸을 등록하면 경고가 뜹니다.
2. 추가한 연락처를 개별 삭제할 수 있습니다. (uuid)
3. 추가한 연락처를 전체 삭제할 수 있습니다.

git 주소:
https://github.com/Hwiwon-source/phonebook.git

도메인 주소: 
https://elaborate-brigadeiros-46ed34.netlify.app

사용한 library
bootstarp, react-bootstrap
redux, react-redux
uuid, fontawesome