import React from 'react'

const ProductDetailPage = () => {
  return (
    <div>
      상품상세정보
    </div>
  )
}

export default ProductDetailPage
