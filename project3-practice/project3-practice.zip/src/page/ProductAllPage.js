import React from 'react'

const ProductAllPage = () => {
  return (
    <div>
      상품전체페이지
    </div>
  )
}

export default ProductAllPage
